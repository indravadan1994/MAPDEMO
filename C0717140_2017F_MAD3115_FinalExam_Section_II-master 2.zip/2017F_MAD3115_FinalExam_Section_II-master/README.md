# 2017F_MAD3115_FinalExam_Section_II

Perform following task

1)	SMS and Phone call features 
2)	Email Sending
3)	Display atleast five location in table view and selecting one location with navigate to display location on map with pointer. Hint: User dictionary to store Location class objects
a.	Create custom Location class containing following fields
    i.	  Location Id
    ii.	  Location Title
    iii.	Latitude 
    iv.	  Longitude
4)	Design navigation mechanism according to your knowledge 
