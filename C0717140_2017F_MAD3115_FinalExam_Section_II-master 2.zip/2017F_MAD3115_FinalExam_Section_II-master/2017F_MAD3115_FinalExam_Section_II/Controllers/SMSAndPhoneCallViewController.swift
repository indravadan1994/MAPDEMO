//
//  ViewController.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by moxDroid on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    :C0717140
//  Name        :Indravadan Shrimali

import UIKit
import MessageUI

let textMessageRecipients = ["1-800-867-5309"]



class SMSAndPhoneCallViewController: UIViewController,MFMessageComposeViewControllerDelegate {
    
    // let messageComposer = MFMessageComposeViewController()
    
   
    
    
    
  
    
    

   
    override func viewDidLoad() {
        super.viewDidLoad()
        
     navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Next", style: .plain, target: self, action: #selector(nextVC))
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
  
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func canSendText() -> Bool {
        return MFMessageComposeViewController.canSendText()
    }
    
    // Configures and returns a MFMessageComposeViewController instance
    func configuredMessageComposeViewController() -> MFMessageComposeViewController {
        let messageComposeVC = MFMessageComposeViewController()
        messageComposeVC.messageComposeDelegate = self  //  Make sure to set this property to self, so that the controller can be dismissed!
        messageComposeVC.recipients = textMessageRecipients
        messageComposeVC.body =  "Sending Text Message through SMS in Swift"
        return messageComposeVC
    }

    
    @IBAction func btnSmsTapped(_ sender: UIButton) {
        
        let composeVC = MFMessageComposeViewController()
        composeVC.messageComposeDelegate = self
        
        // Configure the fields of the interface.
        composeVC.recipients = ["4085551212"]
        composeVC.body = "Hello from California!"
        
        
        if MFMessageComposeViewController.canSendText() {
            present(composeVC, animated: true, completion: nil)
        }
        // Present the view controller modally.
       
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
//        switch result.rawValue {
//        case MessageComposeResult.cancelled :
//            print("message canceled")
//
//        case MessageComposeResult.RawValue :
//            print("message failed")
//
//        case MessageComposeResult.RawValue :
//            print("message sent")
//
//        default:
//            break
//        }
      //  if MessageComposeResult.cancelled
        controller.dismiss(animated: true, completion: nil)
    }
    
    
    @objc func nextVC(){
        
     self.performSegue(withIdentifier: "EmailVC", sender: self)
        
        
        
    }
    
    
    func btnPhoneCallTapped(_ sender: UIButton) {
        let busPhone = "4377752484"
        
        if let url = URL(string: "tel://\(busPhone)"), UIApplication.shared.canOpenURL(url) {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
        
        
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "EmailVC" {
            if let nextVC = segue.destination as? SendEmailViewController {
               // nextVC.selectedBasicPhrase = sender
            }
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }

}

    
    
}

