//
//  LocationListViewController.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by moxDroid on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    :C0717140
//  Name        :IndravadanShrimali

import UIKit

var lat : Double!
var long: Double!


class LocationListViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    
    @IBOutlet weak var tblView: UITableView!
    //1:timesqaure ny 2:efil tower 3: wall of china 4:tajmahal 5:cntower
    var latitude : Array<Double> = [40.7590,48.8584,40.4319,27.1750,43.6426]
    var longitude : Array<Double> = [-73.9845,-2.2945,-116.5704,-78.0422,-79.3871]

    override func viewDidLoad() {
        super.viewDidLoad()
       
        
           navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Next", style: .plain, target: self, action: #selector(nextVC))
        
//        var objLocation =  Location.init(lat,long)
//        objLocation.arr
//
      

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    //MARK: - TABLE VIEW METHODS
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return latitude.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        cell.textLabel?.text = String(latitude[indexPath.row])
        cell.detailTextLabel?.text = String(longitude[indexPath.row])
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            
          lat  = latitude[0]
          long  =  longitude[0]
              self.performSegue(withIdentifier: "map", sender: self)
            
        }
        else if indexPath.row == 1 {
            
            lat  = latitude[1]
            long  =  longitude[1]
              self.performSegue(withIdentifier: "map", sender: self)
            
        }
    }
    

    @objc func nextVC(){
        
        self.performSegue(withIdentifier: "map", sender: self)
        
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "map" {
            if let nextVC = segue.destination as? ShowLocationOnMapViewController {
                
                
                let mapvc = self.storyboard?.instantiateViewController(withIdentifier: "mapVC") as! ShowLocationOnMapViewController
                 mapvc.latitude = lat
                 mapvc.longitude = long 
                
              
              
            }
            // Get the new view controller using segue.destinationViewController.
            // Pass the selected object to the new view controller.
        }
        
    }

}
